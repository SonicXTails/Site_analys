DM Sans is a low-contrast geometric sans serif design, intended for use at smaller text sizes.

DM Sans supports a Latin Extended glyph set, enabling typesetting for English and other Western European languages. It was designed by Colophon Foundry (UK), that started from the Latin portion of ITF [Poppins](https://fonts.google.com/specimen/Poppins), by Jonny Pinhorn.

The DM Sans project was commissoned by Google from [Colophon](“https://colophon-foundry.org“), an international and award-winning type foundry based in London (UK) and Los Angeles (US) who publish and distribute high-quality retail and custom typefaces for analog and digital media. To contribute, see [github.com/googlefonts/dm-fonts](https://github.com/googlefonts/dm-fonts)